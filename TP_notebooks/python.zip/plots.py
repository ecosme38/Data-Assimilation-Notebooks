import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

def isnotebook():
    try:
        shell = get_ipython().__class__.__name__
        if shell == 'ZMQInteractiveShell':
            return True   # Jupyter notebook or qtconsole
        else:
            return False  # Other type (?)
    except NameError:
        return False


def anim(xx, nt, trajectories,**kwargs):

    if not isinstance(trajectories[0], (list, tuple)) :
        trajectories=[trajectories]

    if len(trajectories)==1 :
        animation_1(xx, nt, trajectories, **kwargs)
    elif len(trajectories)==2 :
        animation_2(xx, nt, trajectories, **kwargs)
    elif len(trajectories)==3 :
        animation_3(xx, nt, trajectories, **kwargs)
    elif len(trajectories)==4 :
        animation_4(xx, nt, trajectories, **kwargs)

        
def animation_1(xx, nt, trajectories,legends=None,colors=['k-']):

    if isnotebook():
        plt.rcParams["animation.html"] = "jshtml"

    fig, ax = plt.subplots()
    xdata, ydata = [], []
    ln1, = ax.plot([], [], colors[0], animated=True)
    
    def init():
        ax.set_xlim(0, 1)
        ax.set_ylim(-1, 1)
        if legends!=None:
            ax.legend(legends)
        return ln1,

    def update(i):
        xdata=xx 
        ydata=trajectories[0][i]
        ln1.set_data(xdata,ydata)
        return ln1,

    ani = FuncAnimation(fig, update, np.arange(nt),
                            init_func=init, blit=True)
    plt.show()


def animation_2(xx, nt, trajectories,legends=None,colors=['k-','b-']):
    
    if isnotebook():
        plt.rcParams["animation.html"] = "jshtml"

    fig, ax = plt.subplots()
    xdata, ydata = [], []
    ln1, = ax.plot([], [], colors[0], animated=True)
    ln2, = ax.plot([], [], colors[1], animated=True)
    
    def init():
        ax.set_xlim(0, 1)
        ax.set_ylim(-1, 1)
        if legends!=None:
            ax.legend(legends)
        return ln1,

    def update(i):
        xdata=xx 
        ydata=trajectories[0][i]
        ln1.set_data(xdata,ydata)
        ydata=trajectories[1][i]
        ln2.set_data(xdata,ydata)
        return ln1,ln2,

    ani = FuncAnimation(fig, update, np.arange(nt),
                            init_func=init, blit=True)
    if not isnotebook():
        plt.show()


def animation_3(xx, nt, trajectories,legends=None,colors=['k-','b-','r-']):

    if isnotebook():
        plt.rcParams["animation.html"] = "jshtml"

    fig, ax = plt.subplots()
    xdata, ydata = [], []
    ln1, = ax.plot([], [], colors[0], animated=True)
    ln2, = ax.plot([], [], colors[1], animated=True)
    ln3, = ax.plot([], [], colors[2], animated=True)
    
    def init():
        ax.set_xlim(0, 1)
        ax.set_ylim(-1, 1)
        if legends!=None:
            ax.legend(legends)
        return ln1,

    def update(i):
        xdata=xx 
        ydata=trajectories[0][i]
        ln1.set_data(xdata,ydata)
        ydata=trajectories[1][i]
        ln2.set_data(xdata,ydata)
        ydata=trajectories[2][i]
        ln3.set_data(xdata,ydata)
        return ln1,ln2,ln3,

    ani = FuncAnimation(fig, update, np.arange(nt),
                            init_func=init, blit=True)
    if not isnotebook():
        plt.show()


def animation_4(xx, nt, trajectories,legends=None,colors=['k-','b-','r-','g-']):

    if isnotebook():
        plt.rcParams["animation.html"] = "jshtml"

    fig, ax = plt.subplots()
    xdata, ydata = [], []
    ln1, = ax.plot([], [], colors[0], animated=True)
    ln2, = ax.plot([], [], colors[1], animated=True)
    ln3, = ax.plot([], [], colors[2], animated=True)
    ln4, = ax.plot([], [], colors[3], animated=True)
    
    def init():
        ax.set_xlim(0, 1)
        ax.set_ylim(-1, 1)
        if legends!=None:
            ax.legend(legends)
        return ln1,

    def update(i):
        xdata=xx 
        ydata=trajectories[0][i]
        ln1.set_data(xdata,ydata)
        ydata=trajectories[1][i]
        ln2.set_data(xdata,ydata)
        ydata=trajectories[2][i]
        ln3.set_data(xdata,ydata)
        ydata=trajectories[3][i]
        ln4.set_data(xdata,ydata)
        return ln1,ln2,ln3,ln4,

    ani = FuncAnimation(fig, update, np.arange(nt),
                            init_func=init, blit=True)
    if not isnotebook():
        plt.show()
